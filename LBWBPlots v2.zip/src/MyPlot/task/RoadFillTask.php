<?php

declare(strict_types=1);

namespace MyPlot\task;

use MyPlot\MyPlot;
use MyPlot\Plot;
use pocketmine\block\Block;
use pocketmine\block\BlockIds;
use pocketmine\block\Grass;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\math\Vector3;
use pocketmine\Player;
use pocketmine\scheduler\Task;
use pocketmine\utils\Config;

class RoadFillTask extends Task
{

	private $plugin;
	private $level, $height, $bottomBlock, $plotFillBlock, $plotFloorBlock, $plotBeginPos, $xMax, $zMax, $maxBlocksPerTick;
	private $plot;
	private $plotSize;
	private $test2;
	private $test;
	private $pos;
	private $player;
	private $direction;
	private $grass;
	private $stonerand;
	private $plotWallBlock;
	/**
	 * @var int
	 */
	private $grose;
	/**
	 * @var int
	 */
	private $roadWidth;

	/**
	 * PlotMergeTask constructor.
	 *
	 * @param MyPlot $plugin
	 * @param int $maxBlocksPerTick
	 * @param Plot $plot
	 * @param Player $player
	 */
	public function __construct(MyPlot $plugin, Plot $plot, Player $player, $direction, int $maxBlocksPerTick = 256){
		$this->plugin = $plugin;
		$this->player = $player;
		$this->direction = $direction;
		$this->plotBeginPos = $plugin->getPlotPosition($plot);
		$this->level = $this->plotBeginPos->getLevel();
		$plotLevel = $plugin->getLevelSettings($plot->levelName);
		$plotSize = $plotLevel->plotSize;
		$this->plot5 = $plugin->getPlotByPosition($player);
		$this->plotSize = $plotLevel->plotSize;
		$this->plotWallBlock = $plotLevel->wallBlock;
		$this->grose = $plotLevel->plotSize;
		$this->height = $plotLevel->groundHeight;
		$this->xMax = $this->plotBeginPos->x + 2 + $plotSize;
		$this->zMax = $this->plotBeginPos->z + 2 + $plotSize;
		$this->pos = new Vector3($this->plotBeginPos->x, 0, $this->plotBeginPos->z);
		$this->grass = $plotLevel->plotFloorBlock;
		$this->roadWidth = $plotLevel->roadWidth;
		$this->rand = $plotLevel->wallBlock;
		$this->air = Block::get(0, 0);
	}


	public function onRun(int $currentTick): void{
		$blocks = 0;
		$merge = new Config($this->plugin->getDataFolder() . "merge.yml", 2);
		$pos = $this->player->getPosition();
		$levelName = $this->player->getLevel()->getFolderName();
        $nordplot = $pos->getSide(Vector3::SIDE_NORTH, 64);
        $suedplot = $pos->getSide(Vector3::SIDE_SOUTH, 64);
        $westplot = $pos->getSide(Vector3::SIDE_WEST, 64);
		$eastplot = $pos->getSide(Vector3::SIDE_EAST, 64);
        $nordplot = $this->plugin->getPlotByPosition($nordplot);
        $suedplot = $this->plugin->getPlotByPosition($suedplot);
        $eastplot = $this->plugin->getPlotByPosition($eastplot);
        $westplot = $this->plugin->getPlotByPosition($westplot);
		switch($this->player->getDirection()){
			case 0:
				$direction = "east";
				break;
			case 1:
				$direction = "south";
				break;
			case 2:
				$direction = "west";
				break;
			case 3:
				$direction = "north";
				break;
			default:
			    $this->player->sendMessage($prefix . $this->plugin->translateString("merge.error"));
				return;
				break;
		}

		$x = $this->player->getX();
		$y = $this->player->getY();
		$z = $this->player->getZ();
		###########################################################################################
		###########################################################################################
		###########################################################################################
		###########################################################################################
		###########################################################################################
		#####################################[  MERGE WEST ]#########################################
		###########################################################################################
		###########################################################################################
		###########################################################################################
		###########################################################################################
		###########################################################################################
		if($direction == "west") {
			$abc1 = $this->plot5->X;
            $abc11 = $this->plot5->Z;
            $abc11--;
			$mergewestrechts = "(" . $abc1 . ";" . $abc11 . ")";
			$plotabc1= $this->plugin->getProvider()->getPlot($levelName, $abc1, $abc11);
			$abc2 = $this->plot5->X;
            $abc22 = $this->plot5->Z;
			$abc2--;
            $abc22--;
			$mergewestobenrechts = "(" . $abc2 . ";" . $abc22 . ")";
			$plotabc2= $this->plugin->getProvider()->getPlot($levelName, $abc2, $abc22);
			$abc3 = $this->plot5->X;
            $abc33 = $this->plot5->Z;
			$abc3--;
            $abc33++;
			$mergewestobenlinks = "(" . $abc3 . ";" . $abc33 . ")";
			$plotabc3= $this->plugin->getProvider()->getPlot($levelName, $abc3, $abc33);
			$abc4 = $this->plot5->X;
            $abc44 = $this->plot5->Z;
            $abc44++;
			$mergewestlinks = "(" . $abc4 . ";" . $abc44 . ")";
			$plotabc4= $this->plugin->getProvider()->getPlot($levelName, $abc4, $abc44);
			$abc8 = $this->plot5->X;
			$abc88 = $this->plot5->Z;
			$abc8--;
			$mergewestoben = "(" . $abc8 . ";" . $abc88 . ")";
			if ($merge->getNested($levelName . ".$mergewestrechts")){
				if ($this->player->hasPermission("myplot.admin.merge") or $plotabc1->owner == $this->player->getName()){
					for ($x = $this->plotBeginPos->x - $this->roadWidth + 10; $x <= $this->xMax; $x++) {
						$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 1 + $this->plotSize), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 2 + $this->plotSize), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 3 + $this->plotSize), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 4 + $this->plotSize), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 5 + $this->plotSize), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 6 + $this->plotSize), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 7 + $this->plotSize), $this->grass, false, false);
						$blocks++;
						if ($blocks >= 500) {
							$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
							return;
						}
					}
				}
			}
			if ($merge->getNested($levelName . ".$mergewestlinks")){
				if ($this->player->hasPermission("myplot.admin.merge") or $plotabc4->owner == $this->player->getName()){
					for ($x = $this->plotBeginPos->x - $this->roadWidth + 10; $x <= $this->xMax; $x++) {
						$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 1), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 2), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 3), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 4), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 5), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 6), $this->grass, false, false);
						$blocks++;
						if ($blocks >= 500) {
							$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
							return;
						}
					}
				}
			}
			if ($merge->getNested($levelName . ".$mergewestobenrechts")){
				if ($this->player->hasPermission("myplot.admin.merge") or $plotabc2->owner == $this->player->getName()){
					for ($x = $this->plotBeginPos->x - $this->roadWidth + 10; $x <= $this->xMax; $x++) {
						$this->level->setBlock(new Vector3($x -42, $this->height, $this->plotBeginPos->z - $this->plotSize - 1 + $this->plotSize), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -42, $this->height, $this->plotBeginPos->z - $this->plotSize - 2 + $this->plotSize), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -42, $this->height, $this->plotBeginPos->z - $this->plotSize - 3 + $this->plotSize), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -42, $this->height, $this->plotBeginPos->z - $this->plotSize - 4 + $this->plotSize), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -42, $this->height, $this->plotBeginPos->z - $this->plotSize - 5 + $this->plotSize), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -42, $this->height, $this->plotBeginPos->z - $this->plotSize - 6 + $this->plotSize), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -42, $this->height, $this->plotBeginPos->z - $this->plotSize - 7 + $this->plotSize), $this->grass, false, false);
						$blocks++;
						if ($blocks >= 500) {
							$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
							return;
						}
					}
				}
			}
			if ($merge->getNested($levelName . ".$mergewestobenlinks")){
				if ($this->player->hasPermission("myplot.admin.merge") or $plotabc3->owner == $this->player->getName()){
					for ($x = $this->plotBeginPos->x - $this->roadWidth + 10; $x <= $this->xMax; $x++) {
						$this->level->setBlock(new Vector3($x - 42, $this->height, $this->plotBeginPos->z + $this->plotSize), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 42, $this->height, $this->plotBeginPos->z + $this->plotSize + 1), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 42, $this->height, $this->plotBeginPos->z + $this->plotSize + 2), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 42, $this->height, $this->plotBeginPos->z + $this->plotSize + 3), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 42, $this->height, $this->plotBeginPos->z + $this->plotSize + 4), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 42, $this->height, $this->plotBeginPos->z + $this->plotSize + 5), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x - 42, $this->height, $this->plotBeginPos->z + $this->plotSize + 6), $this->grass, false, false);
						$blocks++;
						if ($blocks >= 500) {
							$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
							return;
						}
					}
				}
			}
			for ($x = $this->plotBeginPos->x - $this->roadWidth + 35; $x <= $this->xMax; $x++) {
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 0), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 1), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 2), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 3), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 4), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 5), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 6), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 7), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 8), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 9), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 10), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 11), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 12), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 13), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 14), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 15), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 16), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 17), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 18), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 19), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 20), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 21), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 22), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 23), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 24), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 25), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 26), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 27), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 28), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 29), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 30), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 31), $this->grass, false, false);
				if ($merge->getNested($levelName . ".$mergewestrechts") and $merge->getNested($levelName . ".$mergewestobenrechts") and $merge->getNested($levelName . ".$mergewestoben")){
					if ($this->player->hasPermission("myplot.admin.merge") or $plotabc2->owner == $this->player->getName() or $plotabc1->owner == $this->player->getName()){
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 7), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 6), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 5), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 4), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 3), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 2), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 1), $this->grass, false, false);
					}
				}
				if ($merge->getNested($levelName . ".$mergewestlinks") and $merge->getNested($levelName . ".$mergewestobenlinks") and $merge->getNested($levelName . ".$mergewestoben")){
					if ($this->player->hasPermission("myplot.admin.merge") or $plotabc3->owner == $this->player->getName() or $plotabc4->owner == $this->player->getName()){
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 32), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 33), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 34), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 35), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 36), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 37), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 38), $this->grass, false, false);
					}
				}
				$blocks++;
				if ($blocks >= 500) {
					$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
					return;
				}
			}
		}
		###########################################################################################
		###########################################################################################
		###########################################################################################
		###########################################################################################
		###########################################################################################
		######################################[  MERGEEAST ]#########################################
		###########################################################################################
		###########################################################################################
		###########################################################################################
		###########################################################################################
		###########################################################################################

		if($direction == "east") {
			$abc1 = $this->plot5->X;
            $abc11 = $this->plot5->Z;
			$abc11++;
			$mergeeastrechts = "(" . $abc1 . ";" . $abc11 . ")";
			$plotabc1= $this->plugin->getProvider()->getPlot($levelName, $abc1, $abc11);
			$abc2 = $this->plot5->X;
            $abc22 = $this->plot5->Z;
			$abc2++;
			$abc22++;
			$mergeeastobenrechts = "(" . $abc2 . ";" . $abc22 . ")";
			$plotabc2= $this->plugin->getProvider()->getPlot($levelName, $abc2, $abc22);
			$abc3 = $this->plot5->X;
            $abc33 = $this->plot5->Z;
			$abc3++;
			$abc33--;
			$mergeeastobenlinks = "(" . $abc3 . ";" . $abc33 . ")";
			$plotabc3= $this->plugin->getProvider()->getPlot($levelName, $abc3, $abc33);
			$abc4 = $this->plot5->X;
            $abc44 = $this->plot5->Z;
			$abc44--;
			$mergeeastlinks = "(" . $abc4 . ";" . $abc44 . ")";
			$plotabc4= $this->plugin->getProvider()->getPlot($levelName, $abc4, $abc44);
			$abc8 = $this->plot5->X;
			$abc88 = $this->plot5->Z;
			$abc8++;
			$mergeeastoben = "(" . $abc8 . ";" . $abc88 . ")";
			if ($merge->getNested($levelName . ".$mergeeastobenrechts")){
				if ($this->player->hasPermission("myplot.admin.merge") or $plotabc2->owner == $this->player->getName()){
				for ($x = $this->plotBeginPos->x - $this->roadWidth + 10; $x <= $this->xMax; $x++) {
					$this->level->setBlock(new Vector3($x +36, $this->height, $this->plotBeginPos->z + $this->plotSize), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +36, $this->height, $this->plotBeginPos->z + $this->plotSize + 1), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +36, $this->height, $this->plotBeginPos->z + $this->plotSize + 2), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +36, $this->height, $this->plotBeginPos->z + $this->plotSize + 3), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +36, $this->height, $this->plotBeginPos->z + $this->plotSize + 4), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +36, $this->height, $this->plotBeginPos->z + $this->plotSize + 5), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +36, $this->height, $this->plotBeginPos->z + $this->plotSize + 6), $this->grass, false, false);
					$blocks++;
					if ($blocks >= 500) {
						$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
						return;
					}
				}
				}
					
			}
			if ($merge->getNested($levelName . ".$mergeeastobenlinks")){
				if ($this->player->hasPermission("myplot.admin.merge") or $plotabc3->owner == $this->player->getName()){
				for ($x = $this->plotBeginPos->x - $this->roadWidth + 10; $x <= $this->xMax; $x++) {
					$this->level->setBlock(new Vector3($x +36, $this->height, $this->plotBeginPos->z - $this->plotSize - 1 + $this->plotSize), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +36, $this->height, $this->plotBeginPos->z - $this->plotSize - 2 + $this->plotSize), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +36, $this->height, $this->plotBeginPos->z - $this->plotSize - 3 + $this->plotSize), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +36, $this->height, $this->plotBeginPos->z - $this->plotSize - 4 + $this->plotSize), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +36, $this->height, $this->plotBeginPos->z - $this->plotSize - 5 + $this->plotSize), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +36, $this->height, $this->plotBeginPos->z - $this->plotSize - 6 + $this->plotSize), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +36, $this->height, $this->plotBeginPos->z - $this->plotSize - 7 + $this->plotSize), $this->grass, false, false);
					$blocks++;
					if ($blocks >= 500) {
						$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
						return;
					}
				}
				}
				
			}
			if ($merge->getNested($levelName . ".$mergeeastrechts")){
				if ($this->player->hasPermission("myplot.admin.merge") or $plotabc1->owner == $this->player->getName()){
				for ($x = $this->plotBeginPos->x - $this->roadWidth + 10; $x <= $this->xMax; $x++) {
					$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 1), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 2), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 3), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 4), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 5), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 6), $this->grass, false, false);
					$blocks++;
					if ($blocks >= 500) {
						$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
						return;
					}
				}
				}
				
			}
			if ($merge->getNested($levelName . ".$mergeeastlinks")){
				if ($this->player->hasPermission("myplot.admin.merge") or $plotabc4->owner == $this->player->getName()){
				for ($x = $this->plotBeginPos->x - $this->roadWidth + 10; $x <= $this->xMax; $x++) {
					$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 1 + $this->plotSize), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 2 + $this->plotSize), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 3 + $this->plotSize), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 4 + $this->plotSize), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 5 + $this->plotSize), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 6 + $this->plotSize), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 7 + $this->plotSize), $this->grass, false, false);
					$blocks++;
					if ($blocks >= 500) {
						$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
						return;
				}
			}
				}
			}
			for ($x = $this->plotBeginPos->x - $this->roadWidth + 35; $x <= $this->xMax; $x++) {
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 0), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 1), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 2), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 3), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 4), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 5), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 6), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 7), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 8), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 9), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 10), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 11), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 12), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 13), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 14), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 15), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 16), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 17), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 18), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 19), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 20), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 21), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 22), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 23), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 24), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 25), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 26), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 27), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 28), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 29), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 30), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 31), $this->grass, false, false);
				if ($merge->getNested($levelName . ".$mergeeastrechts") and $merge->getNested($levelName . ".$mergeeastobenrechts") and $merge->getNested($levelName . ".$mergeeastoben")){
					if ($this->player->hasPermission("myplot.admin.merge") or $plotabc1->owner == $this->player->getName() or $plotabc2->owner == $this->player->getName()){
                    $this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 32), $this->grass, false, false);
				    $this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 33), $this->grass, false, false);
			        $this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 34), $this->grass, false, false);
				    $this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 35), $this->grass, false, false);
				    $this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 36), $this->grass, false, false);
				    $this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 37), $this->grass, false, false);
				    $this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 38), $this->grass, false, false);
				}
				}
				if ($merge->getNested($levelName . ".$mergeeastlinks") and $merge->getNested($levelName . ".$mergeeastobenlinks") and $merge->getNested($levelName . ".$mergeeastoben")){
					if ($this->player->hasPermission("myplot.admin.merge") or $plotabc4->owner == $this->player->getName() or $plotabc3->owner == $this->player->getName()){
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 7), $this->grass, false, false);
				    $this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 6), $this->grass, false, false);
				    $this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 5), $this->grass, false, false);
			        $this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 4), $this->grass, false, false);
				    $this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 3), $this->grass, false, false);
				    $this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 2), $this->grass, false, false);
				    $this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 1), $this->grass, false, false);
				}
			}
				$blocks++;
				if ($blocks >= 500) {
					$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
					return;
				}
			}
		}
  
		###########################################################################################
		###########################################################################################
		###########################################################################################
		###########################################################################################
		###########################################################################################
		####################################[  MERGE SOUTH ]#########################################
		###########################################################################################
		###########################################################################################
		###########################################################################################
		###########################################################################################
		###########################################################################################

		if($direction == "south") {
			$abc1 = $this->plot5->X;
            $abc11 = $this->plot5->Z;
			$abc1--;
			$mergesouthrechts = "(" . $abc1 . ";" . $abc11 . ")";
			$plotabc1= $this->plugin->getProvider()->getPlot($levelName, $abc1, $abc11);
			$abc2 = $this->plot5->X;
            $abc22 = $this->plot5->Z;
			$abc2--;
			$abc22++;
			$mergesouthobenrechts = "(" . $abc2 . ";" . $abc22 . ")";
			$plotabc2= $this->plugin->getProvider()->getPlot($levelName, $abc2, $abc22);
			$abc3 = $this->plot5->X;
            $abc33 = $this->plot5->Z;
			$abc3++;
			$abc33++;
			$mergesouthobenlinks = "(" . $abc3 . ";" . $abc33 . ")";
			$plotabc3= $this->plugin->getProvider()->getPlot($levelName, $abc3, $abc33);
			$abc4 = $this->plot5->X;
            $abc44 = $this->plot5->Z;
			$abc4++;
			$mergesouthlinks = "(" . $abc4 . ";" . $abc44 . ")";
			$plotabc4= $this->plugin->getProvider()->getPlot($levelName, $abc4, $abc44);
			$abc8 = $this->plot5->X;
			$abc88 = $this->plot5->Z;
			$abc88++;
			$mergesouthoben = "(" . $abc8 . ";" . $abc88 . ")";
			if ($merge->getNested($levelName . ".$mergesouthlinks") and $merge->getNested($levelName . ".$mergesouthoben") and $merge->getNested($levelName . ".$mergesouthobenlinks")){
				if ($this->player->hasPermission("myplot.admin.merge") or $plotabc4->owner == $this->player->getName() or $plotabc3->owner == $this->player->getName()){
				for ($x = $this->plotBeginPos->x - $this->roadWidth + 35; $x <= $this->xMax; $x++) {
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 39), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 40), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 41), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 42), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 43), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 44), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 45), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 46), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 47), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 48), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 49), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 50), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 51), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 52), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 53), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 54), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 55), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 56), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 57), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 58), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 59), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 60), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 61), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 62), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 63), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 64), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 65), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 66), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 67), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 68), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 69), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 70), $this->grass, false, false);
					$blocks++;
					if ($blocks >= 500) {
						$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
						return;
					}
				}
				}
			}
			if ($merge->getNested($levelName . ".$mergesouthrechts") and$merge->getNested($levelName . ".$mergesouthoben") and $merge->getNested($levelName . ".$mergesouthobenrechts")){
				if ($this->player->hasPermission("myplot.admin.merge") or $plotabc1->owner == $this->player->getName() or $plotabc2->owner == $this->player->getName()){
				for ($x = $this->plotBeginPos->x - $this->roadWidth + 35; $x <= $this->xMax; $x++) {
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 39), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 40), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 41), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 42), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 43), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 44), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 45), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 46), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 47), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 48), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 49), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 50), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 51), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 52), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 53), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 54), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 55), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 56), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 57), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 58), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 59), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 60), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 61), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 62), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 63), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 64), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 65), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 66), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 67), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 68), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 69), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 70), $this->grass, false, false);
					$blocks++;
					if ($blocks >= 500) {
						$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
						return;
					}
				}
				}
			}
			if ($merge->getNested($levelName . ".$mergesouthlinks")){
				if ($this->player->hasPermission("myplot.admin.merge") or $plotabc4->owner == $this->player->getName()){
				for ($x = $this->plotBeginPos->x - $this->roadWidth + 35; $x <= $this->xMax; $x++) {
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 0), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 1), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 2), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 3), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 4), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 5), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 6), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 7), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 8), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 9), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 10), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 11), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 12), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 13), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 14), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 15), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 16), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 17), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 18), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 19), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 20), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 21), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 22), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 23), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 24), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 25), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 26), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 27), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 28), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 29), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 30), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 31), $this->grass, false, false);
					if ($merge->getNested($levelName . ".$mergesouthlinks") and $merge->getNested($levelName . ".$mergesouthobenlinks") and $merge->getNested($levelName . ".$mergesouthoben")){
						if ($this->player->hasPermission("myplot.admin.merge") or $plotabc4->owner == $this->player->getName() or $plotabc3->owner == $this->player->getName()){
						$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 32), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 33), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 34), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 35), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 36), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 37), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 38), $this->grass, false, false);
					}
					}
					$blocks++;
					if ($blocks >= 500) {
						$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
						return;
					}
				}
				}
			}
			if ($merge->getNested($levelName . ".$mergesouthrechts")){
				if ($this->player->hasPermission("myplot.admin.merge") or $plotabc1->owner == $this->player->getName()){
				for ($x = $this->plotBeginPos->x - $this->roadWidth + 35; $x <= $this->xMax; $x++) {
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 0), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 1), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 2), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 3), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 4), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 5), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 6), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 7), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 8), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 9), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 10), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 11), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 12), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 13), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 14), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 15), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 16), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 17), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 18), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 19), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 20), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 21), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 22), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 23), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 24), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 25), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 26), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 27), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 28), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 29), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 30), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 31), $this->grass, false, false);
					if ($merge->getNested($levelName . ".$mergesouthrechts") and $merge->getNested($levelName . ".$mergesouthobenrechts") and $merge->getNested($levelName . ".$mergesouthoben")){
						if ($this->player->hasPermission("myplot.admin.merge") or $plotabc1->owner == $this->player->getName() or $plotabc2->owner == $this->player->getName()){
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 32), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 33), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 34), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 35), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 36), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 37), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 38), $this->grass, false, false);

					}
					}
					$blocks++;
					if ($blocks >= 500) {
						$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
						return;
					}
				}
				}
			}
			for ($x = $this->plotBeginPos->x - $this->roadWidth + 10; $x <= $this->xMax; $x++) {
				$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 1), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 2), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 3), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 4), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 5), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z + $this->plotSize + 6), $this->grass, false, false);
				$blocks++;
				if ($blocks >= 500) {
					$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
					return;
				}
			}
		}

		###########################################################################################
		###########################################################################################
		###########################################################################################
		###########################################################################################
		###########################################################################################
		#####################################[  MERGE NORTH ]########################################
		###########################################################################################
		###########################################################################################
		###########################################################################################
		###########################################################################################
		###########################################################################################

		if($direction == "north") {
			$abc1 = $this->plot5->X;
            $abc11 = $this->plot5->Z;
			$abc1++;
			$mergenorthrechts = "(" . $abc1 . ";" . $abc11 . ")";
			$plotabc1= $this->plugin->getProvider()->getPlot($levelName, $abc1, $abc11);
			$abc2 = $this->plot5->X;
            $abc22 = $this->plot5->Z;
			$abc2++;
			$abc22--;
			$mergenorthobenrechts = "(" . $abc2 . ";" . $abc22 . ")";
			$plotabc2= $this->plugin->getProvider()->getPlot($levelName, $abc2, $abc22);
			$abc3 = $this->plot5->X;
            $abc33 = $this->plot5->Z;
			$abc3--;
			$abc33--;
			$mergenorthobenlinks = "(" . $abc3 . ";" . $abc33 . ")";
			$plotabc3= $this->plugin->getProvider()->getPlot($levelName, $abc3, $abc33);
			$abc4 = $this->plot5->X;
            $abc44 = $this->plot5->Z;
			$abc4--;
			$mergenorthlinks = "(" . $abc4 . ";" . $abc44 . ")";
			$plotabc4= $this->plugin->getProvider()->getPlot($levelName, $abc4, $abc44);
			$abc8 = $this->plot5->X;
			$abc88 = $this->plot5->Z;
			$abc88--;
			$mergenorthoben = "(" . $abc8 . ";" . $abc88 . ")";
			if ($merge->getNested($levelName . ".$mergenorthlinks") and $merge->getNested($levelName . ".$mergenorthoben") and $merge->getNested($levelName . ".$mergenorthobenlinks")){
				if ($this->player->hasPermission("myplot.admin.merge") or $plotabc4->owner == $this->player->getName() or $plotabc3->owner == $this->player->getName()){
				for ($x = $this->plotBeginPos->x - $this->roadWidth + 35; $x <= $this->xMax; $x++) {
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 8), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 9), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 10), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 11), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 12), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 13), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 14), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 15), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 16), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 17), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 18), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 19), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 20), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 21), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 22), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 23), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 24), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 25), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 26), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 27), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 28), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 29), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 30), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 31), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 32), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 33), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 34), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 35), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 36), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 37), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 38), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 39), $this->grass, false, false);
					$blocks++;
					if ($blocks >= 500) {
						$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
						return;
					}
				}
				}
			}
			if ($merge->getNested($levelName . ".$mergenorthrechts") and$merge->getNested($levelName . ".$mergenorthoben") and $merge->getNested($levelName . ".$mergenorthobenrechts")){
				if ($this->player->hasPermission("myplot.admin.merge") or $plotabc1->owner == $this->player->getName() or $plotabc2->owner == $this->player->getName()){
				for ($x = $this->plotBeginPos->x - $this->roadWidth + 35; $x <= $this->xMax; $x++) {
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 8), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 9), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 10), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 11), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 12), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 13), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 14), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 15), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 16), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 17), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 18), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 19), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 20), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 21), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 22), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 23), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 24), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 25), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 26), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 27), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 28), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 29), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 30), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 31), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 32), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 33), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 34), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 35), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 36), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 37), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 38), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 39), $this->grass, false, false);
					$blocks++;
					if ($blocks >= 500) {
						$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
						return;
					}
				}
				}
			}
			if ($merge->getNested($levelName . ".$mergenorthlinks")){
				if ($this->player->hasPermission("myplot.admin.merge") or $plotabc4->owner == $this->player->getName()){
				for ($x = $this->plotBeginPos->x - $this->roadWidth + 35; $x <= $this->xMax; $x++) {
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 0), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 1), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 2), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 3), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 4), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 5), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 6), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 7), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 8), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 9), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 10), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 11), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 12), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 13), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 14), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 15), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 16), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 17), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 18), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 19), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 20), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 21), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 22), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 23), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 24), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 25), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 26), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 27), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 28), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 29), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 30), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z + 31), $this->grass, false, false);
					if ($merge->getNested($levelName . ".$mergenorthlinks") and $merge->getNested($levelName . ".$mergenorthobenlinks") and $merge->getNested($levelName . ".$mergenorthoben")){
						if ($this->player->hasPermission("myplot.admin.merge") or $plotabc4->owner == $this->player->getName() or $plotabc3->owner == $this->player->getName()){
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 1), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 2), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 3), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 4), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 5), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 6), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x -35, $this->height, $this->plotBeginPos->z - 7), $this->grass, false, false);
					}
					}
					$blocks++;
					if ($blocks >= 500) {
						$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
						return;
					}
				}
				}
			}
			if ($merge->getNested($levelName . ".$mergenorthrechts")){
				if ($this->player->hasPermission("myplot.admin.merge") or $plotabc1->owner == $this->player->getName()){
				for ($x = $this->plotBeginPos->x - $this->roadWidth + 35; $x <= $this->xMax; $x++) {
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 0), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 1), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 2), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 3), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 4), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 5), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 6), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 7), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 8), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 9), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 10), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 11), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 12), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 13), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 14), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 15), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 16), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 17), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 18), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 19), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 20), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 21), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 22), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 23), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 24), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 25), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 26), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 27), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 28), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 29), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 30), $this->grass, false, false);
					$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z + 31), $this->grass, false, false);
					if ($merge->getNested($levelName . ".$mergenorthrechts") and $merge->getNested($levelName . ".$mergenorthobenrechts") and $merge->getNested($levelName . ".$mergenorthoben")){
						if ($this->player->hasPermission("myplot.admin.merge") or $plotabc1->owner == $this->player->getName() or $plotabc2->owner == $this->player->getName()){
						$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 1), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 2), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 3), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 4), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 5), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 6), $this->grass, false, false);
						$this->level->setBlock(new Vector3($x +4, $this->height, $this->plotBeginPos->z - 7), $this->grass, false, false);
					}
					}
					$blocks++;
					if ($blocks >= 500) {
						$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
						return;
					}
				}
				}
			}
			for ($x = $this->plotBeginPos->x - $this->roadWidth + 10; $x <= $this->xMax; $x++) {
				$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 1 + $this->plotSize), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 2 + $this->plotSize), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 3 + $this->plotSize), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 4 + $this->plotSize), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 5 + $this->plotSize), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 6 + $this->plotSize), $this->grass, false, false);
				$this->level->setBlock(new Vector3($x - 3, $this->height, $this->plotBeginPos->z - $this->plotSize - 7 + $this->plotSize), $this->grass, false, false);
				$blocks++;
				if ($blocks >= 500) {
					$this->plugin->getScheduler()->scheduleDelayedTask($this, 1);
					return;
				}
			}
		}
	}
}
