<?php

namespace MyPlot;

use pocketmine\Player;
use MyPlot\MyPlot;
use jojoe77777\FormAPI;
use jojoe77777\FormAPI\SimpleForm;
use pocketmine\utils\Config;
use pocketmine\Server;

class Rand{

    private $plugin;

    public function __consturct(Main $plugin){
        $this->plugin = $plugin;
    }

    public function Rands($player){
        $config = new Config(MyPlot::getInstance()->getDataFolder() . "randwand.yml", 2);
        $form = new SimpleForm(function (Player $player, $data = null){
            $result = $data;
            if($result === null){
                return true;
            }
            $result = explode(":", $result);
            $block = (integer)$result[0];
            $blockid = (integer)$result[1];
            $permission = $result[2];
            $plot = MyPlot::getInstance()->getPlotByPosition($player);
            $prefix = $this->getPlugin()->getLanguage()->get("prefix");
            $config = new Config(MyPlot::getInstance()->getDataFolder() . "randwand.yml", 2);
            if ($player->hasPermission($permission)){
                $player->sendMessage($prefix . $this->getPlugin()->getLanguage()->get("rand.success"));
                MyPlot::getInstance()->newRandPlot($plot, 256, $block, $blockid);
            }else{
                $player->sendMessage($prefix . $this->getPlugin()->getLanguage()->get("rand.nopermission"));
            }
            return false;
        });
        $form->setTitle($this->getPlugin()->getLanguage()->get("rand.title"));
        $form->setContent("");
        foreach($config->get("Rand") as $rand) {
            $form->addButton($rand[0], -1, "", implode(":", [$rand[1], $rand[2], $rand[3]]));
        }
        $form->sendToPlayer($player);
        return $form;
    }

    private function getPlugin(): MyPlot{
        return MyPlot::getInstance();
    }
}