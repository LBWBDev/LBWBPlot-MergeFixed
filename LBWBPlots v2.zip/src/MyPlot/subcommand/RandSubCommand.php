<?php
declare(strict_types=1);
namespace MyPlot\subcommand;

use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat as TF;
use pocketmine\utils\Config;
use MyPlot\MyPlot;
use MyPlot\Rand;

class RandSubCommand extends SubCommand
{
	/**
	 * @param CommandSender $sender
	 *
	 * @return bool
	 */
	public function canUse(CommandSender $sender): bool
	{
		return ($sender instanceof Player) and $sender->hasPermission("myplot.command.rand");
	}

	/**
	 * @param Player $sender
	 * @param string[] $args
	 *
	 * @return bool
	 */
		public function execute(CommandSender $sender, array $args) : bool {
		$prefix = $this->translateString("prefix");
		$plot = $this->getPlugin()->getPlotByPosition($sender);
		$levelName = $sender->getLevel()->getFolderName();
        $merge = new Config($this->getPlugin()->getDataFolder() . "merge.yml", 2);
		$config = new Config($this->getPlugin()->getDataFolder() . "randwand.yml", 2);
		if(!$this->getPlugin()->isLevelLoaded($levelName)) {
			$sender->sendMessage($prefix . $this->translateString("notinworld"));
			return true;
		}
		if($plot === null) {
			$sender->sendMessage($prefix . $this->translateString("notinplot"));
			return true;
		}
		if ($plot->owner !== $sender->getName() and !$sender->hasPermission("myplot.admin.rand")) {
            $sender->sendMessage($prefix . $this->translateString("notowner"));
			return true;
		}
		if ($config->getNested("Rand") == null or $config->get("Rand") == null){
            $sender->sendMessage($prefix . $this->translateString("rand.norand"));
			return true;
		}
        if ($merge->getNested($levelName . ".$plot")){
            $sender->sendMessage($prefix . $this->translateString("rand.merge"));
            return true;
        }
        $cos = new Rand($this, $sender);
        $cos->Rands($sender);
        return true;
	}
}