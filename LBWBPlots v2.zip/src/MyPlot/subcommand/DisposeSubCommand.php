<?php
declare(strict_types=1);
namespace MyPlot\subcommand;

use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat as TF;

class DisposeSubCommand extends SubCommand
{
	/**
	 * @param CommandSender $sender
	 *
	 * @return bool
	 */
	public function canUse(CommandSender $sender) : bool {
		return ($sender instanceof Player) and $sender->hasPermission("myplot.command.dispose");
	}

	/**
	 * @param Player $sender
	 * @param string[] $args
	 *
	 * @return bool
	 */
	public function execute(CommandSender $sender, array $args) : bool {

        $prefix = $this->translateString("prefix");

        $plot = $this->getPlugin()->getPlotByPosition($sender);
		$levelName = $sender->getLevel()->getFolderName();
		if(!$this->getPlugin()->isLevelLoaded($levelName)) {
			$sender->sendMessage($prefix . $this->translateString("notinworld"));
			return true;
		}
		if($plot === null) {
			$sender->sendMessage($prefix . $this->translateString("notinplot"));
            return true;
		}
		if($plot->owner !== $sender->getName() and !$sender->hasPermission("myplot.admin.dispose")) {
            $sender->sendMessage($prefix . $this->translateString("notowner"));
            return true;
		}
		if(isset($args[0]) and $args[0] == "confirm") {
			if($this->getPlugin()->disposePlot($plot)) {
                $this->getPlugin()->newRandPlot($plot, 256, 44, 4);
				$sender->sendMessage($prefix . $this->translateString("dispose.success"));
			}else{
				$sender->sendMessage($prefix . $this->translateString("error"));
			}
		}else{
			$plotId = $plot;
			$sender->sendMessage($prefix . $this->translateString("dispose.confirm", [$plotId]));
		}
		return true;
	}
}