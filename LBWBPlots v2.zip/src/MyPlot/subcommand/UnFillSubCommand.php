<?php
declare(strict_types=1);
namespace MyPlot\subcommand;

use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class UnFillSubCommand extends SubCommand {

	/**
	 * @param CommandSender $sender
	 *
	 * @return bool
	 */
	public function canUse(CommandSender $sender) : bool {
		return ($sender instanceof Player) and $sender->hasPermission("myplot.command.unfill");
	}

	/**
	 * @param Player $sender
	 * @param string[] $args
	 *
	 * @return bool
	 */
	public function execute(CommandSender $sender, array $args) : bool {

        $prefix = $this->translateString("prefix");

		$plot = $this->getPlugin()->getPlotByPosition($sender);
		$levelName = $sender->getLevel()->getFolderName();
		if(!$this->getPlugin()->isLevelLoaded($levelName)) {
			$sender->sendMessage($prefix . $this->translateString("notinworld"));
			return true;
		}
		if($plot === null) {
			$sender->sendMessage($prefix . $this->translateString("notinplot"));
			return true;
		}
		if($plot->owner !== $sender->getName() and !$sender->hasPermission("myplot.admin.unfill")) {
            $sender->sendMessage($prefix . $this->translateString("notowner"));
			return true;
		}
		$merge = new Config($this->getPlugin()->getDataFolder() . "merge.yml", 2);
		if ($merge->getNested($sender->getPlayer()->getLevel()->getName() . ".$plot")) {
			$sender->sendMessage($prefix . $this->translateString("unfill.mergeerror"));
			return true;
		} else {

			$economy = $this->getPlugin()->getEconomyProvider();
			$plotLevel = $this->getPlugin()->getLevelSettings($plot->levelName);
			if (isset($args[0]) and $args[0] == "confirm") {
			    $this->getPlugin()->unfillPlot($plot);
				$sender->sendMessage($prefix . $this->translateString("unfill.success"));
				return true;
			} else {
				$plotId = $plot;
				$sender->sendMessage($prefix . $this->translateString("unfill.confirm", [$plotId]));
				return true;
			}
		}
	}
}