<?php
declare(strict_types=1);
namespace MyPlot\subcommand;

use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat as TF;

class UnTrustSubCommand extends SubCommand
{
	/**
	 * @param CommandSender $sender
	 *
	 * @return bool
	 */
	public function canUse(CommandSender $sender) : bool {
		return ($sender instanceof Player) and $sender->hasPermission("myplot.command.untrust");
	}

	/**
	 * @param Player $sender
	 * @param string[] $args
	 *
	 * @return bool
	 */
	public function execute(CommandSender $sender, array $args) : bool {
        $prefix = $this->translateString("prefix");
        if(empty($args)) {
			return false;
		}
		$helper = $args[0];
		$plot = $this->getPlugin()->getPlotByPosition($sender);
		$levelName = $sender->getLevel()->getFolderName();
		if(!$this->getPlugin()->isLevelLoaded($levelName)) {
			$sender->sendMessage($prefix . $this->translateString("notinworld"));
			return true;
		}
		if($plot === null) {
			$sender->sendMessage($prefix . $this->translateString("notinplot"));
			return true;
		}
		if($plot->owner !== $sender->getName() and !$sender->hasPermission("myplot.admin.untrust")) {
            $sender->sendMessage($prefix . $this->translateString("notowner"));
			return true;
		}
		$helper = $this->getPlugin()->getServer()->getPlayer($helper);
		if (!$helper instanceof Player){
			if($this->getPlugin()->removePlotHelper($plot, $args[0])) {
				$sender->sendMessage($prefix . $this->translateString("untrust.success", [$args[0]]));
			}else{
				$sender->sendMessage($prefix . $this->translateString("error"));
			}
		}else{
			if($this->getPlugin()->removePlotHelper($plot, $helper->getName())) {
				$sender->sendMessage($prefix . $this->translateString("untrust.success", [$helper->getName()]));
			}else{
				$sender->sendMessage($prefix . $this->translateString("error"));
			}
		}
		return true;
	}
}