<?php
declare(strict_types=1);
namespace MyPlot\subcommand;

use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat as TF;

class ReloadSubCommand extends SubCommand
{
	/**
	 * @param CommandSender $sender
	 *
	 * @return bool
	 */
	public function canUse(CommandSender $sender) : bool {
		return ($sender->hasPermission("myplot.command.reload"));
	}

	/**
	 * @param Player $sender
	 * @param string[] $args
	 *
	 * @return bool
	 */
	public function execute(CommandSender $sender, array $args) : bool {
		$prefix = $this->translateString("prefix");
		$this->getPlugin()->reloadConfig();
		$this->getPlugin()->saveResource("randwand.yml");
		$this->getPlugin()->onDisable();
		$this->getPlugin()->onLoad();
		$this->getPlugin()->onEnableReload();
		$sender->sendMessage($prefix . $this->translateString("reload.load"));
		sleep(1);
		$prefix = $this->translateString("prefix");
		$sender->sendMessage($prefix . $this->translateString("reload.success"));
		$this->getPlugin()->getLogger()->info(TF::BOLD.TF::GREEN."MyPlot-Mergefix wurde reloadet!");
		return true;
	}
}