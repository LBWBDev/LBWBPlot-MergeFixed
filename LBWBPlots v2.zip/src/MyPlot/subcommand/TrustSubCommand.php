<?php
declare(strict_types=1);
namespace MyPlot\subcommand;

use pocketmine\command\CommandSender;
use pocketmine\OfflinePlayer;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat as TF;
use pocketmine\utils\Config;

class TrustSubCommand extends SubCommand
{
	/**
	 * @param CommandSender $sender
	 *
	 * @return bool
	 */
	public function canUse(CommandSender $sender): bool
	{
		return ($sender instanceof Player) and $sender->hasPermission("myplot.command.trust");
	}

	/**
	 * @param Player $sender
	 * @param string[] $args
	 *
	 * @return bool
	 */
	public function execute(CommandSender $sender, array $args): bool{
        $prefix = $this->translateString("prefix");
		if (empty($args)) {
			return false;
		}
		$helper = $args[0];
		$merge = new Config($this->getPlugin()->getDataFolder() . "merge.yml", 2);
		$plot = $this->getPlugin()->getPlotByPosition($sender);
		$levelName = $sender->getLevel()->getFolderName();
		if(!$this->getPlugin()->isLevelLoaded($levelName)) {
			$sender->sendMessage($prefix . $this->translateString("notinworld"));
			return true;
		}
		if ($plot === null) {
			$sender->sendMessage($prefix . $this->translateString("notinplot"));
			return true;
		}
		if ($plot->owner !== $sender->getName() and !$sender->hasPermission("myplot.admin.addhelper")) {
            $sender->sendMessage($prefix . $this->translateString("notowner"));
			return true;
		}
		$helper = $this->getPlugin()->getServer()->getPlayer($helper);
		if (!$helper instanceof Player){
			if ($helper === $args[0]){
				$sender->sendMessage($prefix . $this->translateString("trust.toself"));
				return true;
			}
			if ($merge->exists($levelName . ".$plot")) {
                $sender->sendMessage($prefix . $this->translateString("trust.success", [$args[0]]));
				if ($this->getPlugin()->addPlotHelper($plot, $args[0])) {
				} else {
					$sender->sendMessage($prefix . $this->translateString("error"));
				}
			} else {
                $sender->sendMessage($prefix . $this->translateString("trust.success", [$args[0]]));
				if ($this->getPlugin()->addPlotHelper($plot, $args[0])) {
				} else {
					$sender->sendMessage($prefix . $this->translateString("error"));
				}
			}
			if($helper === "*") {
				if ($this->getPlugin()->addPlotHelper($plot, $args[0])) {
					$sender->sendMessage($prefix . $this->translateString("trust.success", [$helper]));
				}else{
					$sender->sendMessage($prefix . $this->translateString("error"));
				}
				return true;
			}
		}else{
			if ($helper === $sender->getName()){
				$sender->sendMessage($prefix . $this->translateString("trust.toself"));
				return true;
			}
			if ($merge->exists($levelName . ".$plot")) {
                $sender->sendMessage($prefix . $this->translateString("trust.success", [$helper->getName()]));
				if ($this->getPlugin()->addPlotHelper($plot, $helper->getName())) {
				} else {
					$sender->sendMessage($prefix . $this->translateString("error"));
				}
			} else {
                $sender->sendMessage($prefix . $this->translateString("trust.success", [$helper->getName()]));
				if ($this->getPlugin()->addPlotHelper($plot, $helper->getName())) {
				} else {
					$sender->sendMessage($prefix . $this->translateString("error"));
				}
			}
			if($helper === "*") {
				if ($this->getPlugin()->addPlotHelper($plot, $helper->getName())) {
					$sender->sendMessage($prefix . $this->translateString("trust.success", [$helper]));
				}else{
					$sender->sendMessage($prefix . $this->translateString("error"));
				}
				return true;
			}
		}
		return true;
	}
}