<?php
declare(strict_types=1);
namespace MyPlot\subcommand;

use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use MyPlot\provider\SQLiteDataProvider;
use pocketmine\plugin\PluginDescription;
use pocketmine\plugin\PluginLoader;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Config;
use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI;
use MyPlot\Commands;
use MyPlot\MyPlot;
use MyPlot\Plot;
use MyPlot\subcommand\SubCommand;
use pocketmine\level\Level;
use pocketmine\utils\TextFormat as TF;

class ResetSubCommand extends SubCommand
{
	/**
	 * @param CommandSender $sender
	 *
	 * @return bool
	 */
	public function canUse(CommandSender $sender) : bool {
		return ($sender instanceof Player) and $sender->hasPermission("myplot.command.reset");
	}

	/**
	 * @param Player $sender
	 * @param string[] $args
	 *
	 * @return bool
	 */
	public function execute(CommandSender $sender, array $args) : bool {

        $prefix = $this->translateString("prefix");

		$levelName = $sender->getLevel()->getFolderName();
		if(!$this->getPlugin()->isLevelLoaded($levelName)) {
			$sender->sendMessage($prefix . $this->translateString("notinworld"));
			return true;
		}
        $plot = $this->getPlugin()->getPlotByPosition($sender);
		if($plot === null) {
			$sender->sendMessage($prefix . $this->translateString("notinplot"));
            return true;
		}
		if($plot->owner !== $sender->getName() and !$sender->hasPermission("myplot.admin.reset")) {
            $sender->sendMessage($prefix . $this->translateString("notowner"));
			return true;
		}
		if(isset($args[0]) and $args[0] == "confirm") {
			$maxBlocksPerTick = $this->getPlugin()->getConfig()->get("ClearBlocksPerTick", 256);
			$levelName = $sender->getLevel()->getFolderName();
			$merge = new Config($this->getPlugin()->getDataFolder() . "merge.yml", 2);
			switch($sender->getDirection()){
				case 0:
					$direction = "east";
					break;
				case 1:
					$direction = "south";
					break;
				case 2:
					$direction = "west";
					break;
				case 3:
					$direction = "north";
					break;
				default:
				$sender->sendMessage($prefix . $this->translateString("merge.error"));
					return false;
					break;
			}
			if($direction == "north"){
				if($this->getPlugin()->resetPlot($plot, $maxBlocksPerTick)) {
					$this->getPlugin()->newRandPlot($plot, 256, 44,  6);
					$this->getPlugin()->newWandResetPlot($plot, 256, 0, 0);
					$this->getPlugin()->unmergeResetPlot($plot, $sender, $direction);
					$merge->remove("$plot");
					$merge->removeNested($sender->getLevel()->getName() . "." . "$plot");
					$merge->removeNested($sender->getLevel()->getName() . ".$plot");
					$merge->save();
					$sender->sendMessage($prefix . $this->translateString("reset.success"));
			}else{
				$sender->sendMessage($prefix . $this->translateString("error"));
			}
			}
			if($direction == "west"){
				if($this->getPlugin()->resetPlot($plot, $maxBlocksPerTick)) {
					$this->getPlugin()->newRandPlot($plot, 256, 44,  6);
					$this->getPlugin()->newWandResetPlot($plot, 256, 0, 0);
					$this->getPlugin()->unmergeResetPlot($plot, $sender, $direction);
					$merge->remove("$plot");
					$merge->removeNested($sender->getLevel()->getName() . "." . "$plot");
					$merge->removeNested($sender->getLevel()->getName() . ".$plot");
					$merge->save();
					$sender->sendMessage($prefix . $this->translateString("reset.success"));
			}else{
				$sender->sendMessage($prefix . $this->translateString("error"));
			}
			}
			if($direction == "south"){
				if($this->getPlugin()->resetPlot($plot, $maxBlocksPerTick)) {
					$this->getPlugin()->newRandPlot($plot, 256, 44,  6);
					$this->getPlugin()->newWandResetPlot($plot, 256, 0, 0);
					$this->getPlugin()->unmergeResetPlot($plot, $sender, $direction);
					$merge->remove("$plot");
					$merge->removeNested($sender->getLevel()->getName() . "." . "$plot");
					$merge->removeNested($sender->getLevel()->getName() . ".$plot");
					$merge->save();
					$sender->sendMessage($prefix . $this->translateString("reset.success"));
			}else{
				$sender->sendMessage($prefix . $this->translateString("error"));
			}
			}
			if($direction == "east"){
				if($this->getPlugin()->resetPlot($plot, $maxBlocksPerTick)) {
					$this->getPlugin()->newRandPlot($plot, 256, 44,  6);
					$this->getPlugin()->newWandResetPlot($plot, 256, 0, 0);
					$this->getPlugin()->unmergeResetPlot($plot, $sender, $direction);
					$merge->remove("$plot");
					$merge->removeNested($sender->getLevel()->getName() . "." . "$plot");
					$merge->removeNested($sender->getLevel()->getName() . ".$plot");
					$merge->save();
					$sender->sendMessage($prefix . $this->translateString("reset.success"));
			}else{
				$sender->sendMessage($prefix . $this->translateString("error"));
			}
			}
		}else{
			$plotId = $plot;
            $sender->sendMessage($prefix . $this->translateString("reset.confirm",  [$plotId]));
		}
		return true;
	}
}