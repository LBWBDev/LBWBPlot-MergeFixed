<?php
declare(strict_types=1);
namespace MyPlot\subcommand;

use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat as TF;

class GiveSubCommand extends SubCommand
{
	/**
	 * @param CommandSender $sender
	 *
	 * @return bool
	 */
	public function canUse(CommandSender $sender) : bool {
		return ($sender instanceof Player) and $sender->hasPermission("myplot.command.give");
	}

	/**
	 * @param Player $sender
	 * @param string[] $args
	 *
	 * @return bool
	 */
	public function execute(CommandSender $sender, array $args) : bool {

        $prefix = $this->translateString("prefix");

        if(empty($args)) {
			return false;
		}
		$newOwner = $args[0];
		$plot = $this->getPlugin()->getPlotByPosition($sender);
		$levelName = $sender->getLevel()->getFolderName();
		if(!$this->getPlugin()->isLevelLoaded($levelName)) {
			$sender->sendMessage($prefix . $this->translateString("notinworld"));
			return true;
		}
		if($plot === null) {
			$sender->sendMessage($prefix . $this->translateString("notinplot"));
            return true;
        }
		if($plot->owner !== $sender->getName()) {
            $sender->sendMessage($prefix . $this->translateString("notowner"));
            return true;
		}
		$newOwner = $this->getPlugin()->getServer()->getPlayer($newOwner);
		if(!$newOwner instanceof Player) {
			$sender->sendMessage($prefix . $this->translateString("give.notonline"));
			return true;
		}elseif($newOwner->getName() === $sender->getName()) {
			$sender->sendMessage($prefix . $this->translateString("give.toself"));
			return true;
		}
		$maxPlots = $this->getPlugin()->getMaxPlotsOfPlayer($newOwner);
		$plotsOfPlayer = count($this->getPlugin()->getPlotsOfPlayer($newOwner->getName(), $newOwner->getLevel()->getFolderName()));
		if($plotsOfPlayer >= $maxPlots) {
			$sender->sendMessage($prefix . $this->translateString("give.maxedout"));
			return true;
		}
		if(count($args) == 2 and $args[1] == "confirm") {
			if($this->getPlugin()->claimPlot($plot, $newOwner->getName())) {
				$plotId = $plot;
				$oldOwnerName = $sender->getName();
				$newOwnerName = $newOwner->getName();
				$sender->sendMessage($prefix . $this->translateString("give.success", [$newOwnerName, $plotId]));
				$newOwner->sendMessage($prefix . $this->translateString("give.received", [$oldOwnerName, $plotId]));
			}else{
				$sender->sendMessage($prefix . $this->translateString("error"));
			}
		}else{
			$plotId = $plot;
			$newOwnerName = $newOwner->getName();
			$sender->sendMessage($prefix . $this->translateString("give.confirm", [$plotId, $newOwnerName]));
		}
		return true;
	}
}