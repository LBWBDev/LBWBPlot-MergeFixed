<?php
declare(strict_types=1);
namespace MyPlot\subcommand;

use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class HomesSubCommand extends SubCommand
{
	/**
	 * @param CommandSender $sender
	 *
	 * @return bool
	 */
	public function canUse(CommandSender $sender) : bool {
		return ($sender instanceof Player) and $sender->hasPermission("myplot.command.homes");
	}

	/**
	 * @param Player $sender
	 * @param string[] $args
	 *
	 * @return bool
	 */
	public function execute(CommandSender $sender, array $args) : bool {
		$prefix = $this->translateString("prefix");
		$levelName = $args[0] ?? $sender->getLevel()->getFolderName();
		$plots = $this->getPlugin()->getPlotsOfPlayer($sender->getName(), $levelName);
		$levelName3 = $sender->getLevel()->getFolderName();
		if(!$this->getPlugin()->isLevelLoaded($levelName3)) {
			$sender->sendMessage($prefix . $this->translateString("noinworld"));
			return true;
		}
		if(empty($plots)) {
			$sender->sendMessage($prefix . $this->translateString("homes.noplots"));
			return true;
		}
		$sender->sendMessage($prefix . $this->translateString("homes.header"));
		for($i = 0; $i < count($plots); $i++) {
			$plot = $plots[$i];
			$message = TextFormat::DARK_GREEN . ($i + 1) . ") ";
			$message .= "§r§7" . $plot->levelName . " §6" . $plot;
			if($plot->name !== "") {
				$message .= " §7= §b" . $plot->name;
			}
			$sender->sendMessage($message);
		}
		return true;
	}
}