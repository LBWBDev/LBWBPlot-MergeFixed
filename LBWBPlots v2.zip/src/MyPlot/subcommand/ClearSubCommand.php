<?php
declare(strict_types=1);
namespace MyPlot\subcommand;

use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat as TF;

class ClearSubCommand extends SubCommand
{
	/**
	 * @param CommandSender $sender
	 *
	 * @return bool
	 */
	public function canUse(CommandSender $sender) : bool {
		return ($sender instanceof Player) and $sender->hasPermission("myplot.command.clear");
	}

	/**
	 * @param Player $sender
	 * @param string[] $args
	 *
	 * @return bool
	 */
	public function execute(CommandSender $sender, array $args) : bool {

        $prefix = $this->translateString("prefix");

        $plot = $this->getPlugin()->getPlotByPosition($sender);
		$levelName = $sender->getLevel()->getFolderName();
		if(!$this->getPlugin()->isLevelLoaded($levelName)) {
			$sender->sendMessage($prefix . $this->translateString("notinworld"));
			return true;
		}
		if($plot === null) {
			$sender->sendMessage($prefix . $this->translateString("notinplot"));
            return true;
        }
		if($plot->owner !== $sender->getName() and !$sender->hasPermission("myplot.admin.clear")) {
            $sender->sendMessage($prefix . $this->translateString("notowner"));
			return true;
        }
		if(isset($args[0]) and $args[0] == "confirm") {
			/** @var int $maxBlocksPerTick */
			$maxBlocksPerTick = (int) $this->getPlugin()->getConfig()->get("ClearBlocksPerTick", 256);
			if($this->getPlugin()->clearPlot($plot, $maxBlocksPerTick)) {
				$sender->sendMessage($prefix . $this->translateString("clear.success"));
			}else{
				$sender->sendMessage($prefix . $this->translateString("error"));
			}
		}else{
			$plotId = $plot;
			$sender->sendMessage($prefix . $this->translateString("clear.confirm", [$plotId]));
        }
		return true;
	}
}