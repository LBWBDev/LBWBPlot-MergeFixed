<?php
declare(strict_types=1);
namespace MyPlot\subcommand;

use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat as TF;
use pocketmine\utils\Config;

class KickSubCommand extends SubCommand
{
	/**
	 * @param CommandSender $sender
	 *
	 * @return bool
	 */
	public function canUse(CommandSender $sender): bool
	{
		return ($sender instanceof Player) and $sender->hasPermission("myplot.command.kick");
	}

	/**
	 * @param Player $sender
	 * @param string[] $args
	 *
	 * @return bool
	 */
		public function execute(CommandSender $sender, array $args) : bool {
			$prefix = $this->translateString("prefix");
		if (!isset($args[0])) {
			$sender->sendMessage($prefix . $this->translateString("kick.usage"));
			return true;
		}
		$plot = $this->getPlugin()->getPlotByPosition($sender);
		$levelName = $sender->getLevel()->getFolderName();
		if(!$this->getPlugin()->isLevelLoaded($levelName)) {
			$sender->sendMessage($prefix . $this->translateString("notinworld"));
			return true;
		}
		if($plot === null) {
			$sender->sendMessage($prefix . $this->translateString("notinplot"));
			return true;
		}
		if ($plot->owner !== $sender->getName() and !$sender->hasPermission("myplot.admin.kick")) {
            $sender->sendMessage($prefix . $this->translateString("notowner"));
			return true;
		}
		$target = $this->getPlugin()->getServer()->getPlayer($args[0]);
		if ($target === null) {
			$sender->sendMessage($prefix . $this->translateString("kick.notonline"));
			return true;
		}
		if ($target === $sender->getName()) {
			$sender->sendMessage($prefix . $this->translateString("kick.toself"));
			return true;
		}
		if ($this->getPlugin()->getPlotByPosition($target)->isSame($plot)) {
			if ($target->hasPermission("myplot.admin.kick.bypass")) {
				$sender->sendMessage($prefix . $this->translateString("kick.notkick", [$target->getName()]));
				return true;
			}
			if ($this->getPlugin()->teleportPlayerToPlot($target, $plot)) {
				$sender->sendMessage($prefix . $this->translateString("kick.success", [$target->getName()]));
				$sender->sendMessage($prefix . $this->translateString("kick.kicked", [$sender->getName()]));
				return true;
			} else {
				$sender->sendMessage($prefix . $this->translateString("error"));
			}
			return true;
		} else {
			$sender->sendMessage($prefix . $this->translateString("kkick.notplot", [$target]));
			return true;
		}
	}
}