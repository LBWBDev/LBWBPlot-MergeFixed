<?php
declare(strict_types=1);
namespace MyPlot\subcommand;

use MyPlot\Plot;
use pocketmine\command\CommandSender;
use pocketmine\OfflinePlayer;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class BanSubCommand extends SubCommand
{
	/**
	 * @param CommandSender $sender
	 *
	 * @return bool
	 */
	public function canUse(CommandSender $sender) : bool {
		return ($sender instanceof Player) and $sender->hasPermission("myplot.command.ban");
	}

	/**
	 * @param Player $sender
	 * @param string[] $args
	 *
	 * @return bool
	 */
	public function execute(CommandSender $sender, array $args) : bool {
		$prefix = $this->translateString("prefix");
		if(count($args) === 0) {
			return false;
		}
		$dplayer = $args[0];
		$plot = $this->getPlugin()->getPlotByPosition($sender);
		$levelName = $sender->getLevel()->getFolderName();
		if(!$this->getPlugin()->isLevelLoaded($levelName)) {
			$sender->sendMessage($prefix . $this->translateString("notinworld"));
			return true;
		}
		if($plot === null) {
			$sender->sendMessage($prefix . $this->translateString("notinplot"));
			return true;
		}
		if($plot->owner !== $sender->getName() and !$sender->hasPermission("myplot.admin.ban")) {
			$sender->sendMessage($prefix . $this->translateString("notowner"));
			return true;
		}
		if($dplayer === "*") {
			if($this->getPlugin()->addPlotDenied($plot, $dplayer)) {
				$sender->sendMessage($prefix . $this->translateString("ban.success", [$dplayer]));
				foreach($this->getPlugin()->getServer()->getOnlinePlayers() as $player) {
					if($this->getPlugin()->getPlotBB($plot)->isVectorInside($player) and !($player->getName() === $plot->owner) and !$player->hasPermission("myplot.admin.ban.bypass") and !$plot->isHelper($player->getName()))
						$this->getPlugin()->teleportPlayerToPlot($player, $plot);
					else {
					}
				}
			}else{
				$sender->sendMessage($prefix . $this->translateString("error"));
			}
			return true;
		}
		$dplayer = $this->getPlugin()->getServer()->getPlayer($dplayer);
		if (!$dplayer instanceof Player){
			if($args[0] === $plot->owner) {
				$sender->sendMessage($prefix . $this->translateString("ban.toself"));
				return true;
			}
			if($this->getPlugin()->addPlotDenied($plot, $args[0])) {
				$sender->sendMessage($prefix . $this->translateString("ban.success", [$args[0]]));
				if(!$dplayer instanceof Player) {
				}else{
					if($this->getPlugin()->getPlotBB($plot)->isVectorInside($dplayer))
						$this->getPlugin()->teleportPlayerToPlot($dplayer, $plot);
				}
			}else{
				$sender->sendMessage($prefix . $this->translateString("error"));
			}
		}else{
			if($dplayer->getName() === $plot->owner) {
				$sender->sendMessage($prefix . $this->translateString("ban.toself"));
				return true;
			}
			if($this->getPlugin()->addPlotDenied($plot, $dplayer->getName())) {
				$sender->sendMessage($prefix . $this->translateString("ban.success", [$dplayer->getName()]));
				if(!$dplayer instanceof Player) {
				}else{
					if($this->getPlugin()->getPlotBB($plot)->isVectorInside($dplayer))
						$this->getPlugin()->teleportPlayerToPlot($dplayer, $plot);
				}
			}else{
				$sender->sendMessage($prefix . $this->translateString("error"));
			}
		}		
		return true;
	}
}