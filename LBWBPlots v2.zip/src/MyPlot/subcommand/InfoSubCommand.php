<?php
declare(strict_types=1);
namespace MyPlot\subcommand;

use MyPlot\Plot;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\Config;
use pocketmine\math\Vector3;
use pocketmine\level\Position;
use pocketmine\utils\TextFormat as TF;

class InfoSubCommand extends SubCommand
{
	/**
	 * @param CommandSender $sender
	 *
	 * @return bool
	 */
	public function canUse(CommandSender $sender) : bool {
		return ($sender instanceof Player) and $sender->hasPermission("myplot.command.info");
	}

	/**
	 * @param Player $sender
	 * @param string[] $args
	 *
	 * @return bool
	 */
	public function execute(CommandSender $sender, array $args) : bool {

        $prefix = $this->translateString("prefix");
		$player = $sender->getServer()->getPlayer($sender->getName());
		$plot = $this->getPlugin()->getPlotByPosition($player);
		$levelName = $sender->getLevel()->getFolderName();
		if(!$this->getPlugin()->isLevelLoaded($levelName)) {
			$sender->sendMessage($prefix . $this->translateString("notinworld"));
			return true;
		}
		if($plot === null) {
			$sender->sendMessage($prefix . $this->translateString("notinplot"));
            return true;
		}
		if($plot->owner != "") {
			if($plot->owner === $sender->getName()) {
				if(isset($args[0])) {
					if(isset($args[1]) and is_numeric($args[1])) {
						$key = ((int) $args[1] - 1) < 1 ? 1 : ((int) $args[1] - 1);
						/** @var Plot[] $plots */
						$plots = [];
						foreach($this->getPlugin()->getPlotLevels() as $levelName => $settings) {
							$plots = array_merge($plots, $this->getPlugin()->getPlotsOfPlayer($args[0], $levelName));
						}
						if(isset($plots[$key])) {
							$plot = $plots[$key];
							$name1 = "§b" . $plot->name;
							$owner1 = "§b" . $plot->owner;
							$helpers1 = implode("§7, §b", $plot->helpers);
							$denied1 = implode("§7, §b", $plot->denied);
							$header =  $this->translateString("info.header", [$plot]);
							$name = $this->translateString("info.names", [$name1]);
							$owner = $this->translateString("info.owner", [$owner1]);
							$helpers = $this->translateString("info.helper", [$helpers1]);
							$denied = $this->translateString("info.deny", [$denied1]);
		                    $sender->sendMessage($prefix . $this->translateString("info.design", [$header, $name, $owner, $helpers, $denied]));
						}else{
							$sender->sendMessage($prefix . $this->translateString("info.notfound"));
						}
					}else{
						return false;
					}
				} else {
					$plot = $this->getPlugin()->getPlotByPosition($sender);
					if ($plot === null) {
						$sender->sendMessage($prefix . $this->translateString("notinplot"));
						return true;
					}
					$name1 = "§b" . $plot->name;
					$owner1 = "§b" . $plot->owner;
					$helpers1 = implode("§7, §b", $plot->helpers);
					$denied1 = implode("§7, §b", $plot->denied);
					$mergeon = $this->translateString("info.merge.on");
					$mergeoff = $this->translateString("info.merge.off");
					$merge2 = new Config($this->getPlugin()->getDataFolder() . "merge.yml", 2);
					if ($merge2->getNested($sender->getPlayer()->getLevel()->getName() . ".$plot")) {
						$merge1 = $mergeon;
					} else {
						$merge1 = $mergeoff;
					}
					$header =  $this->translateString("info.header", [$plot]);
					$name = $this->translateString("info.names", [$name1]);
					$owner = $this->translateString("info.owner", [$owner1]);
					$helpers = $this->translateString("info.helper", [$helpers1]);
					$denied = $this->translateString("info.deny", [$denied1]);
					$merge = $this->translateString("info.merge", [$merge1]);
					$sender->sendMessage($prefix . $this->translateString("info.design", [$header, $name, $owner, $helpers, $denied, $merge]));
				}
			}else{
				if(isset($args[0])) {
					if(isset($args[1]) and is_numeric($args[1])) {
						$key = ((int) $args[1] - 1) < 1 ? 1 : ((int) $args[1] - 1);
						/** @var Plot[] $plots */
						$plots = [];
						foreach($this->getPlugin()->getPlotLevels() as $levelName => $settings) {
							$plots = array_merge($plots, $this->getPlugin()->getPlotsOfPlayer($args[0], $levelName));
						}
						if(isset($plots[$key])) {
							$plot = $plots[$key];
							$name1 = "§b" . $plot->name;
							$owner1 = "§b" . $plot->owner;
							$helpers1 = implode("§7, §b", $plot->helpers);
							$denied1 = implode("§7, §b", $plot->denied);
							$header =  $this->translateString("info.header", [$plot]);
							$name = $this->translateString("info.names", [$name1]);
							$owner = $this->translateString("info.owner", [$owner1]);
							$helpers = $this->translateString("info.helper", [$helpers1]);
							$denied = $this->translateString("info.deny", [$denied1]);
		                    $sender->sendMessage($prefix . $this->translateString("info.design", [$header, $name, $owner, $helpers, $denied]));
						}else{
							$sender->sendMessage($prefix . $this->translateString("info.notfound"));
						}
					}else{
						return false;
					}
				} else {
					$plot = $this->getPlugin()->getPlotByPosition($sender);
					if ($plot === null) {
						$sender->sendMessage($prefix . $this->translateString("notinplot"));
						return true;
					}
					$name1 = "§b" . $plot->name;
					$owner1 = "§b" . $plot->owner;
					$helpers1 = implode("§7, §b", $plot->helpers);
					$denied1 = implode("§7, §b", $plot->denied);
					$mergeon = $this->translateString("info.merge.on");
					$mergeoff = $this->translateString("info.merge.off");
					$merge2 = new Config($this->getPlugin()->getDataFolder() . "merge.yml", 2);
					if ($merge2->getNested($sender->getPlayer()->getLevel()->getName() . ".$plot")) {
						$merge1 = $mergeon;
					} else {
						$merge1 = $mergeoff;
					}
					$header =  $this->translateString("info.header", [$plot]);
					$name = $this->translateString("info.names", [$name1]);
					$owner = $this->translateString("info.owner", [$owner1]);
					$helpers = $this->translateString("info.helper", [$helpers1]);
					$denied = $this->translateString("info.deny", [$denied1]);
					$merge = $this->translateString("info.merge", [$merge1]);
					$sender->sendMessage($prefix . $this->translateString("info.design", [$header, $name, $owner, $helpers, $denied, $merge]));
				}
			}
			return true;
		}else{
			$sender->sendMessage($prefix . $this->translateString("info.notowner"));
		}
		return true;
	}
}