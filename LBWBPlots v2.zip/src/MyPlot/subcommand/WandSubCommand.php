<?php
declare(strict_types=1);
namespace MyPlot\subcommand;

use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat as TF;
use pocketmine\utils\Config;
use MyPlot\MyPlot;
use MyPlot\Wand;

class WandSubCommand extends SubCommand
{
	/**
	 * @param CommandSender $sender
	 *
	 * @return bool
	 */
	public function canUse(CommandSender $sender): bool
	{
		return ($sender instanceof Player) and $sender->hasPermission("myplot.command.wand");
	}

	/**
	 * @param Player $sender
	 * @param string[] $args
	 *
	 * @return bool
	 */
		public function execute(CommandSender $sender, array $args) : bool {
		$prefix = $this->translateString("prefix");
		$plot = $this->getPlugin()->getPlotByPosition($sender);
		$levelName = $sender->getLevel()->getFolderName();
        $merge = new Config($this->getPlugin()->getDataFolder() . "merge.yml", 2);
		$config = new Config($this->getPlugin()->getDataFolder() . "randwand.yml", 2);
		if(!$this->getPlugin()->isLevelLoaded($levelName)) {
			$sender->sendMessage($prefix . $this->translateString("notinworld"));
			return true;
		}
		if($plot === null) {
			$sender->sendMessage($prefix . $this->translateString("notinplot"));
			return true;
		}
		if ($plot->owner !== $sender->getName() and !$sender->hasPermission("myplot.admin.wand")) {
            $sender->sendMessage($prefix . $this->translateString("notowner"));
			return true;
		}
		if ($config->getNested("Wand") == null or $config->get("Wand") == null){
            $sender->sendMessage($prefix . $this->translateString("wand.nowand"));
			return true;
		}
        if ($merge->getNested($levelName . ".$plot")){
            $sender->sendMessage($prefix . $this->translateString("wand.merge"));
            return true;
        }
        $cos = new Wand($this, $sender);
        $cos->Wands($sender);
        return true;
	}
}