<?php
declare(strict_types=1);
namespace MyPlot\subcommand;

use pocketmine\command\CommandSender;
use pocketmine\Player;
use pocketmine\utils\TextFormat;

class UnBanSubCommand extends SubCommand
{
	/**
	 * @param CommandSender $sender
	 *
	 * @return bool
	 */
	public function canUse(CommandSender $sender) : bool {
		return ($sender instanceof Player) and $sender->hasPermission("myplot.command.unban");
	}

	/**
	 * @param Player $sender
	 * @param string[] $args
	 *
	 * @return bool
	 */
	public function execute(CommandSender $sender, array $args) : bool {
        $prefix = $this->translateString("prefix");
		if(count($args) === 0) {
			return false;
		}
		$dplayer = $args[0];
		$plot = $this->getPlugin()->getPlotByPosition($sender);
		$levelName = $sender->getLevel()->getFolderName();
		if(!$this->getPlugin()->isLevelLoaded($levelName)) {
			$sender->sendMessage($prefix . $this->translateString("noinworld"));
			return true;
		}
		if($plot === null) {
			$sender->sendMessage($prefix . $this->translateString("notinplot"));
			return true;
		}
		if($plot->owner !== $sender->getName() and !$sender->hasPermission("myplot.admin.unban")) {
			$sender->sendMessage($prefix . $this->translateString("notowner"));
			return true;
		}
		$dplayer = $this->getPlugin()->getServer()->getPlayer($dplayer);
		if (!$dplayer instanceof Player){
			if($this->getPlugin()->removePlotDenied($plot, $args[0])) {
				$sender->sendMessage($prefix . $this->translateString("unban.success", [$args[0]]));
			}else{
				$sender->sendMessage($prefix . $this->translateString("unban.notban", [$args[0]]));
			}
		}else{
			if($this->getPlugin()->removePlotDenied($plot, $dplayer->getName())) {
				$sender->sendMessage($prefix . $this->translateString("unban.success", [$dplayer->getName()]));
			}else{
				$sender->sendMessage($prefix . $this->translateString("unban.notban", [$dplayer->getName()]));
			}
		}
		return true;
	}
}